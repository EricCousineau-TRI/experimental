
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.0'
version = '1.15.0'
full_version = '1.15.0.dev0+7d247f4'
git_revision = '7d247f44768b0935286d1034bedadffc0f5bdf40'
release = False

if not release:
    version = full_version
