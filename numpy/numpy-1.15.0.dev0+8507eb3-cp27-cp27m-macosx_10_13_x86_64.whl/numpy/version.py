
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.0'
version = '1.15.0'
full_version = '1.15.0.dev0+8507eb3'
git_revision = '8507eb30b60ae833eef103929a9e7ace2f8d3a75'
release = False

if not release:
    version = full_version
