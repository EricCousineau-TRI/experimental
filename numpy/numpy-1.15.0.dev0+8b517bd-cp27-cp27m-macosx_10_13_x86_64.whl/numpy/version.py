
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.0'
version = '1.15.0'
full_version = '1.15.0.dev0+8b517bd'
git_revision = '8b517bd2ccf37dd51191052e2b39be4f92d42bca'
release = False

if not release:
    version = full_version
