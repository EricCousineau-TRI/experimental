
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.0'
version = '1.15.0'
full_version = '1.15.0.dev0+6721890'
git_revision = '6721890e86291b53fb8dcbee6809891c348ae98e'
release = False

if not release:
    version = full_version
